package com.example.foodOrdering.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.fooddelivery.dao.AdminLoginRepository;
import com.example.fooddelivery.dao.MenuRepository;
import com.example.fooddelivery.dao.OrdersRepository;
import com.example.fooddelivery.dao.PaymentRepository;
import com.example.fooddelivery.dao.SignupRepository;
import com.example.fooddelivery.demo.FoodOrderingApplication;
import com.example.fooddelivery.model.AdminLogin;
import com.example.fooddelivery.model.Menu;
import com.example.fooddelivery.model.Orders;
import com.example.fooddelivery.model.Payment;
import com.example.fooddelivery.model.Signup;


@SpringBootTest(classes=FoodOrderingApplication.class)
@TestMethodOrder(OrderAnnotation.class)
class FoodOrderingApplicationTests {

	
	@Autowired
	MenuRepository mrepo;
	
	
	@Test
	@Order(1)
	public void menuCreate()
	{
		Menu m=new Menu();
		
		m.setDishname("burger");
		m.setPrice(100);
		m.setAvailablity("Yes");
		m.setDescription("abcd");
		m.setCurations("Indian");
		m.setDeliveryfee("20");
		mrepo.save(m);
		assertNotNull(mrepo.findById(1).get());
	}
	
	@Test
	@Order(2)
	public void menuRead()
	{
		List<Menu> list=mrepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	@Order(3)
	public void menuReadById()
	{
		 Menu m=mrepo.findById(1).get();
		 assertEquals("burger",m.getDishname());
	}

	@Test
	@Order(4)
	public void menuupdate() {
		Menu m=mrepo.findById(1).get();
		m.setPrice(150);
		mrepo.save(m);
		assertNotEquals(100, mrepo.findById(1).get().getPrice());
	}
	
	@Autowired
	PaymentRepository prepo;
	
	@Test
	@Order(5)
	public void newpay() {
		Payment p=new Payment();
		p.setPayment_date("03-14-2022");
		p.setPayment_mode("gpay");
		prepo.save(p);
		assertNotNull(prepo.findById(1).get());
	}
	
	@Test
	@Order(6)
	public void payRead()
	{
		List<Payment> list=prepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	@Order(7)
	public void payReadById()
	{
		 Payment p=prepo.findById(1).get();
		 assertEquals("gpay",p.getPayment_mode());
	}

	@Test
	@Order(8)
	public void  payDelete()
	{
		prepo.deleteById(1);
		assertThat(prepo.existsById(1)).isFalse();
	}
	
	@Autowired
	SignupRepository srepo;
	
	
	@Test
	@Order(9)
	public void createSignup()
	{
		Signup s=new Signup();
	   
		s.setFirst_name("hemnath");
		s.setLast_name("ab");
		s.setCity("chennai");
		s.setState("TN");
		s.setEmail_id("abc@gmail.com");
		s.setPassword("asdf");
		s.setPhone_no("9874567894");
		srepo.save(s);
		assertNotNull(srepo.findById(1).get());
	}
	
	@Test
	@Order(10)
	public void signupRead()
	{
		List<Signup> list=srepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	@Test
	@Order(11)
	public void signupReadById()
	{
		Signup m=srepo.findById(1).get();
		 assertEquals("TN",m.getState());
	}

	@Test
	@Order(12)
	public void regupdate() {
		Signup m=srepo.findById(1).get();
		m.setLast_name("zxc");;
		srepo.save(m);
		assertNotEquals("ab", srepo.findById(1).get().getLast_name());
	}
	@Autowired
	AdminLoginRepository arepo;

	@Autowired
	OrdersRepository orepo;
	@Test
	@Order(13)
	public void showAdmin() {
		List<AdminLogin> list=arepo.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	 @Test
		@Order(14)
		public void  menuDelete()
		{
			mrepo.deleteById(1);
			assertThat(mrepo.existsById(1)).isFalse();
		}
	 @Test
		@Order(15)
		public void  regDelete()
		{
			srepo.deleteById(1);
			assertThat(srepo.existsById(1)).isFalse();
		}
}
