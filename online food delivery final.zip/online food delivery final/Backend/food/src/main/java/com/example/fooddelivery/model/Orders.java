package com.example.fooddelivery.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;



@Entity
@Table(name="orders")
public class Orders {
	
	@Id
	@Column(name="order_id")
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int order_id;
	
	@Column(name="address")
	private String address;
	
	@Column(name="quantity")
	private String quantity;
	
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "user_id")
	private Signup user_id;
	
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "menuId")
	private Menu menuid;
	
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="payment_id")
	private Payment payment_id;

	public Orders(int order_id,  String address, String quantity,Signup user_id,
			Menu menuid) {
		super();
		this.order_id = order_id;
		
		this.address = address;
		this.quantity = quantity;
	
		this.user_id = user_id;
		this.menuid = menuid;
	}
	@JsonProperty ("payment")
	public Payment getPayment_id() {
		return payment_id;
	}

	public void setPayment_id(Payment payment_id) {
		this.payment_id = payment_id;
	}

	public Orders(Payment payment_id) {
		super();
		this.payment_id = payment_id;
	}

	public Orders() {
		
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	@JsonProperty ("user")
	public Signup getUser_id() {
		return user_id;
	}

	public void setUser_id(Signup user_id) {
		this.user_id = user_id;
	}
@JsonProperty("product")
	public Menu getMenuid() {
		return menuid;
	}

	public void setMenuid(Menu menuid) {
		this.menuid = menuid;
	}
	
}