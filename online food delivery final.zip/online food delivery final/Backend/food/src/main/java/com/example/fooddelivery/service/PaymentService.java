package com.example.fooddelivery.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dao.PaymentRepository;
import com.example.fooddelivery.model.Payment;

@Service
public class PaymentService {

	@Autowired
	PaymentRepository payRep;
	
	public Payment savePay(Payment payment) {
		return payRep.save(payment);
	}
	
}
