package com.example.fooddelivery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.exception.ResourceNotFoundException;
import com.example.fooddelivery.model.Menu;
import com.example.fooddelivery.service.MenuService;



@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/food")
@RestController
public class MenuController {

	@Autowired
	MenuService menuService;
	
	@GetMapping("/menus")
	public List<Menu> getAllMenu() {
		List<Menu> menuList = menuService.fetchAllMenu();
		return menuList;
	}
	
	@GetMapping("/menus/{id}")
	public ResponseEntity<Menu> getMenuById(@PathVariable("id") int menuId)
			throws ResourceNotFoundException {
		Menu menu = menuService.getMenuById(menuId);
		return ResponseEntity.ok().body(menu);
	}
	
	@PostMapping("/menus")
	public Menu addMenu(@RequestBody Menu menuu) {
		Menu menu = menuService.saveMenu(menuu);
		return menu;
	}
	
	@PutMapping("/menus/{id}")
	public ResponseEntity<Menu> updateMenu(@PathVariable("id") int menuId,@RequestBody Menu menuDetails) 
			throws ResourceNotFoundException {
		Menu menu = menuService.getMenuById(menuId);

		menu.setDishname(menuDetails.getDishname());
		menu.setPrice(menuDetails.getPrice());
		menu.setAvailablity(menuDetails.getAvailablity());
		menu.setDeliveryfee(menuDetails.getDeliveryfee());
		
		final Menu updatedmenu = menuService.saveMenu(menu);
		return ResponseEntity.ok(updatedmenu);
	}


	@DeleteMapping("/menus/{id}")
	public ResponseEntity<String> deleteMenu(@PathVariable("id") int menuId) {
		menuService.deleteMenuById(menuId);
		return (ResponseEntity<String>) new ResponseEntity<>("1 Item deleted successsfully", HttpStatus.OK);
	}
	
}
