package com.example.fooddelivery.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.fooddelivery.model.Signup;



public interface SignupValidateRepository extends JpaRepository<Signup, String>{
	@Query("SELECT u FROM Signup u WHERE u.email_id =?1 and u.password=?2")
	public Signup validateUser(String email_id,String password);	
}
