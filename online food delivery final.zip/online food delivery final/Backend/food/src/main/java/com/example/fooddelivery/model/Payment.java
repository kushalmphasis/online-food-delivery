package com.example.fooddelivery.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Payment")
public class Payment {

	
	@Column(name="paymentMode")
	private String payment_mode;
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int payment_id;
	
	
	
	@Column(name="Date")
	private String payment_date;
	

	@Override
	public String toString() {
		return "Payment [payment_id=" + payment_id + ", payment_mode=" + payment_mode + ", payment_date=" + payment_date
				+ "]";
	}

	public Payment() {
		
	}
	
	public int getPayment_id() {
		return payment_id;
	}

	public void setPayment_id(int payment_id) {
		this.payment_id = payment_id;
	}

	public String getPayment_mode() {
		return payment_mode;
	}

	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}

	public String getPayment_date() {
		return payment_date;
	}

	public void setPayment_date(String payment_date) {
		this.payment_date = payment_date;
	}
	
	
}
