export class Product {
    menu_id:number=0;
    dish_name:string="";
    description:string="";
    dish_price:number=0;
    availablity:string="";
    delivery_fee:string="";
    curations:string="";
   

}