import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { AloginComponent } from './alogin/alogin.component';
import { AproductListComponent } from './aproduct-list/aproduct-list.component';
import { ContactComponent } from './contact/contact.component';
import { CreateOrderComponent } from './create-order/create-order.component';
import { CreateProductComponent } from './create-product/create-product.component';
import { CreateRegisterComponent } from './create-register/create-register.component';
import { GallaryComponent } from './gallary/gallary.component';
import { HomeComponent } from './home/home.component';
import { HproductListComponent } from './hproduct-list/hproduct-list.component';
import { MenuComponent } from './menu/menu.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { OrderListComponent } from './order-list/order-list.component';
import { PaymentComponent } from './payment/payment.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductListComponent } from './product-list/product-list.component';
import { RegisterDeatilsComponent } from './register-deatils/register-deatils.component';
import { RegisterListComponent } from './register-list/register-list.component';
import { UloginComponent } from './ulogin/ulogin.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { UpdateRegisterComponent } from './update-register/update-register.component';
import { APdetailsComponent } from './a-pdetails/a-pdetails.component';

const routes: Routes = [
  {path:"contact",component: ContactComponent},
  {path:"gallary",component: GallaryComponent},
  {path:"menu",component:MenuComponent},
  {path:"",component: HomeComponent},
  { path: 'registers', component: RegisterListComponent },
  { path: 'add', component: CreateRegisterComponent },
  { path: 'update/:user_id', component: UpdateRegisterComponent },
  { path: 'details/:user_id', component: RegisterDeatilsComponent },
  { path: 'adetails/:menu_id', component:APdetailsComponent },
  { path: 'products', component: ProductListComponent },
  { path: 'padd', component: CreateProductComponent },
  { path: 'pupdate/:menu_id', component: UpdateProductComponent },
  { path: 'pdetails/:menu_id', component: ProductDetailsComponent },
  { path: 'ulogin', component: UloginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'orders', component: OrderListComponent },
  { path: 'mdetails/:order_id', component: OrderDetailsComponent },
  { path: 'oadd', component: CreateOrderComponent },
  { path: 'alogin', component: AloginComponent },
  { path: 'aproducts', component: AproductListComponent },
  { path: 'hproducts', component: HproductListComponent },
  { path: 'transaction',component:PaymentComponent}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
