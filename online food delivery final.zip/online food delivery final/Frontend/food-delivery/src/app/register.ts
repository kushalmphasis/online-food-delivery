export interface Registerinfo {
    user_id:number;
    first_name:string;
    lastname:string;
    city:string;
    email_id:string;
    phone_no:string;
    password:string;
    state:string;
}