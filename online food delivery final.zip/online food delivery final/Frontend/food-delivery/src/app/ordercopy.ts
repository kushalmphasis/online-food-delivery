export class Ordercopy {
}

import { Payment } from "./payment";
import { Product } from "./product";
import { Productinfo} from "./productcopy";
import { Registerinfo } from "./register";

export class Orderinfo {
    
    order_id: number=0;
    user:Registerinfo | undefined;
    address:string="";
    quantity:string="";
    payment_id:number=0;
    // user_id:number=0;
    product:Productinfo | undefined;
    payment:Payment | undefined;



    // menu_id:number=0;
    // dish_name:string="";
    // description:string="";
    // dish_price:number=0;
    // availablity:string="";
    // delivery_fee:string="";
    // curations:string="";

   
   

    constructor(product:Product ) {
 
    //  this.menu_id=this.menu_id;
    //  this.dish_name=this.dish_name;
    //  this.description=this.description;
    //  this.dish_price=this.dish_price;
    //  this.availablity=this.availablity;
    //  this.delivery_fee= this.delivery_fee;
    //  this.curations=this.curations;
    //  this.payment=new Payment (); 

    }
  
    
}



