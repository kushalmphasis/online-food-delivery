export class Payment {

   
   constructor(public payment_mode: String,
    public payment_id:number,
    public payment_date:Date
    ) {

}
}
