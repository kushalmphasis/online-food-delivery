import { ComponentFixture, TestBed } from '@angular/core/testing';

import { APdetailsComponent } from './a-pdetails.component';

describe('APdetailsComponent', () => {
  let component: APdetailsComponent;
  let fixture: ComponentFixture<APdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ APdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(APdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
