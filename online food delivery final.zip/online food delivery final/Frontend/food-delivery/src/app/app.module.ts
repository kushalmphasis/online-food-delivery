import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { AloginComponent } from './alogin/alogin.component';
import { AproductListComponent } from './aproduct-list/aproduct-list.component';
import { ContactComponent } from './contact/contact.component';
import { CreateOrderComponent } from './create-order/create-order.component';
import { CreateProductComponent } from './create-product/create-product.component';
import { CreateRegisterComponent } from './create-register/create-register.component';

import { GallaryComponent } from './gallary/gallary.component';

import { HomeComponent } from './home/home.component';
import { HproductListComponent } from './hproduct-list/hproduct-list.component';
import { MenuComponent } from './menu/menu.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { OrderListComponent } from './order-list/order-list.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductListComponent } from './product-list/product-list.component';
import { RegisterDeatilsComponent } from './register-deatils/register-deatils.component';
import { RegisterListComponent } from './register-list/register-list.component';
import { UloginComponent } from './ulogin/ulogin.component';
import { UpdateRegisterComponent } from './update-register/update-register.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { PaymentComponent } from './payment/payment.component';
import { APdetailsComponent } from './a-pdetails/a-pdetails.component';





// const Approutes: Routes = [
// {path:"",component:WelcomeComponent},
// {path:"welcome",component:WelcomeComponent,children:[

//   {path:"alogin",component:AloginComponent,outlet:'mphasis'},
//   {path:"contact",component:ContactComponent,outlet:'mphasis'},
//   {path:"hproducts",component:HproductListComponent,outlet:'mphasis'},
//   {path:"gallary",component:GallaryComponent,outlet:'mphasis'},
//   {path:"ulogin",component:UloginComponent,outlet:'mphasis'},
//   {path:"create-register",component:CreateRegisterComponent,outlet:'mphasis'}


  
//   {path:"contact",component: ContactComponent},
//   {path:"gallary",component: GallaryComponent},
//   {path:"menu",component:MenuComponent},
//   {path:"",component: HomeComponent},
//   { path: 'registers', component: RegisterListComponent },
//   { path: 'add', component: CreateRegisterComponent },
//   { path: 'update/:user_id', component: UpdateRegisterComponent },
//   { path: 'details/:user_id', component: RegisterDeatilsComponent },
//   { path: 'products', component: ProductListComponent },
//   { path: 'padd', component: CreateProductComponent },
//   { path: 'pupdate/:product_id', component: UpdateProductComponent },
//   { path: 'pdetails/:product_id', component: ProductDetailsComponent },
//   // { path: 'login', component: LoginComponent },
//   { path: 'home', component: HomeComponent },
//   { path: 'admin', component: AdminComponent },
//   { path: 'orders', component: OrderListComponent },
//   { path: 'mdetails/:order_id', component: OrderDetailsComponent },
//   { path: 'oadd', component: CreateOrderComponent },
//   { path: 'alogin', component: AloginComponent },
//   { path: 'aproducts', component: AproductListComponent },
//   { path: 'hproducts', component: HproductListComponent }
 

// ]}
// ]



@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    AloginComponent,
    AproductListComponent,
    ContactComponent,
    CreateOrderComponent,
    CreateProductComponent,
    CreateRegisterComponent,

    GallaryComponent,
 
    HomeComponent,
    HproductListComponent,
    MenuComponent,
    OrderDetailsComponent,
    OrderListComponent,
    ProductDetailsComponent,
    ProductListComponent,
    RegisterDeatilsComponent,
    RegisterListComponent,
    UloginComponent,
    UpdateRegisterComponent,
    UpdateProductComponent,
    WelcomeComponent,
    PaymentComponent,
    APdetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule,
    RouterModule ,
    ReactiveFormsModule
    // .forRoot(Approutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
