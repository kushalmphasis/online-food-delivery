import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Register } from '../employee';
import { RegisterService } from '../user.service';

@Component({
  selector: 'app-create-register',
  templateUrl: './create-register.component.html',
  styleUrls: ['./create-register.component.css']
})
export class CreateRegisterComponent implements OnInit {
  // title = 'Registration done';
  // register: Register = new Register();
  // submitted = false;

  // constructor(private registerService: RegisterService, private router: Router) { }

  // ngOnInit() {
  // }

  // newRegister(): void {
  //   this.submitted = false;
  //   this.register = new Register();
  // }

  // save() {
  //   this.registerService.createRegister(this.register).subscribe(data => {
  //     console.log(data+" "+this.register)
  //    this.register = new Register();
  //     this.gotoList();
  //   },
  //  error => console.log(error));
  // }

  // onSubmit() {
  //   this.submitted = true;
  //   this.save();    
  // }

  // gotoList() {
  //   this.router.navigate(['/ulogin']);
  // }


  // demo.......
   
  submitted = false;
 state: any=["Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli", "Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Orissa", "Pondicherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Tripura", "Uttaranchal", "Uttar Pradesh", "West Bengal"];
  
  
  addUser: FormGroup|any;
  router: any;
 
  
  
  constructor( private registerService:RegisterService,router:Router) { }

  
  
  ngOnInit(): void {

     this.addUser=new FormGroup( {
      first_name: new FormControl( null ,[Validators.required]),
      lastname: new FormControl( null,[Validators.required] ),
      email_id: new FormControl( null,[Validators.required] ),
      password: new FormControl( null,[Validators.required] ),
      city: new FormControl(null,[Validators.required]),
      phone_no: new FormControl('',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
      state: new FormControl( null,[Validators.required] ),
    } );
    
  } 
  get f() {return this.addUser.controls}


  
  
  
 

  SaveData() {
    //console.log( this.addStudent.value );
    this.submitted=true;

    if(this.addUser.invalid){
      return;
    }
    console.log(this.addUser.value);
    this.registerService.createRegister(this.addUser.value).subscribe(data => {
          console.log(data+" "+this.addUser)
          this.submitted=false;
          // this.gotoList();
        
    
      
    } );
    this.addUser.reset({});
    
    
      
    

  }
//   gotoList() {
//     this.router.navigate(['/ulogin']);
// }

}